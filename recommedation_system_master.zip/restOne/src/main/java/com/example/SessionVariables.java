package com.example;

public class SessionVariables {
	
	private String selectedType;
	
	public String getSelectedType() {
		return selectedType;
	}
	
	public void setSelectedType(String selectedType) {
		this.selectedType = selectedType;
	}

}
